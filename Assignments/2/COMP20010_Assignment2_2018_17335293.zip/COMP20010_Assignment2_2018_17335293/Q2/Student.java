/**
 * Student
 */
public class Student implements Comparable {

    private String name;
    private int age;
    private double GPA;

    /**
     * Student class Constructor
     * 
     * @param name the name to set
     * @param age  the age to set
     * @param GPA  the GPA to set
     */
    public Student(String name, int age, double GPA) {
        this.name = name;
        this.age = age;
        this.GPA = GPA;
    }

    @Override
    public String toString() {
        return "name: " + name + "\tage: " + age + "\tGPA: " + GPA;
    }

    @Override
    public int compareTo(Object st) {
        Student comp = (Student) st;
        if (GPA == comp.GPA)
            return 0;
        else if (GPA > comp.GPA)
            return 1;
        else
            return -1;

    }

}